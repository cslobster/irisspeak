#!/usr/bin/env python3
"""Turn mapped utterances (data/mapped/*.jsonl) into next-card training states.

One state per prefix position of each accepted utterance:
  {"id", "split", "source", "setting", "partner", "history", "prefix": [card ids], "targets": {card id: weight}}
where targets is the soft set of acceptable next cards (or "<aac_end>") given the prefix, pooled over the
utterance's acceptable sequence variants.

Splits: aactext and turk use their published splits; AAC Conversations train file -> train with 5 percent of
conversations held out as dev, test file -> test. A per-card cap limits how often any card is the reference
target in train (default 2 percent), which stops "i", "you", "the" dominating.

Usage: python3 data/build_states.py --out data/states
"""
import argparse, json, os, random, collections, re
QRE = re.compile(r"^(what|who|where|when|why|how|which|do|does|did|are|is|can|could|would|will|should|have|has|want|need|shall|may)\b", re.I)
def is_question(t): return bool(t) and (t.strip().endswith("?") or bool(QRE.match(t.strip())))
TOPIC_BIAS = {"diversity","diverse","multicultural","cultural","culture","cultures","community","unity","tradition","traditions","festival","festivals"}

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SETTING_KW = {
    "school": ["school", "class", "teacher", "lesson", "playground", "homework", "library", "college", "university"],
    "doctor": ["doctor", "hospital", "clinic", "nurse", "appointment", "medical", "therapy", "dentist", "pharmacy"],
    "restaurant": ["restaurant", "cafe", "coffee", "shop", "store", "market", "mall", "bakery", "supermarket", "order"],
    "home": ["home", "kitchen", "bedroom", "living room", "family", "dinner", "breakfast", "morning", "bedtime", "house"],
    "play": ["park", "playground", "game", "sports", "beach", "outdoor", "zoo", "birthday", "party", "picnic"],
    "transport": ["bus", "train", "car", "airport", "taxi", "travel", "station", "flight"],
    "selfcare": ["bath", "shower", "bed", "toilet", "dressing", "sleep", "night"],
}
def setting_of(scene):
    s = (scene or "").lower()
    for k, kws in SETTING_KW.items():
        if any(w in s for w in kws): return k
    return "unknown"

def states_for(seqs, max_variants=3):
    """Pool acceptable sequences into per-prefix soft targets. Reference (first) sequence gets extra weight."""
    seqs = seqs[:max_variants]
    out = {}  # prefix tuple -> Counter of next
    for vi, s in enumerate(seqs):
        w = 2.0 if vi == 0 else 1.0
        for k in range(len(s) + 1):
            nxt = s[k] if k < len(s) else "<aac_end>"
            out.setdefault(tuple(s[:k]), collections.Counter())[nxt] += w
    res = []
    for prefix, cnt in out.items():
        tot = sum(cnt.values())
        res.append((list(prefix), {c: round(v / tot, 4) for c, v in cnt.items()}))
    return res

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mapped", default=os.path.join(ROOT, "data", "mapped"))
    ap.add_argument("--out", default=os.path.join(ROOT, "data", "states"))
    ap.add_argument("--cap", type=float, default=0.02, help="max share of train reference targets per card")
    ap.add_argument("--max-cards", type=int, default=6, help="drop utterances whose reference reply is longer")
    ap.add_argument("--seed", type=int, default=13)
    a = ap.parse_args()
    random.seed(a.seed); os.makedirs(a.out, exist_ok=True)

    speaker = {}
    for fn in ("aacconversations_en_train.jsonl", "aacconversations_en_test.jsonl"):
        for l in open(os.path.join(ROOT, "data", "processed", fn)):
            r = json.loads(l); speaker[r["id"]] = (r["speaker"], r.get("target_text", ""))
    utts = []  # (split, source, setting, partner, history, seqs, uid)
    # AACText: no partner
    for l in open(os.path.join(a.mapped, "aactext_imagine.jsonl")):
        e = json.loads(l)
        utts.append((e["split"], "aactext", "unknown", None, [], e["acceptable_sequences"], e["id"]))
    # Turk: prev turn is the partner; skip when the filter emptied it
    for l in open(os.path.join(a.mapped, "turk_dialogues_turns.jsonl")):
        e = json.loads(l)
        partner = e.get("prev_utterance") or None
        utts.append((e["split"] or "train", "turk", "unknown", partner, [], e["acceptable_sequences"], e["id"]))
    # AAC Conversations: hold out 5% of train conversations as dev
    conv_ids = sorted({json.loads(l)["conversation_id"] for l in open(os.path.join(a.mapped, "aacconversations_en_train.jsonl"))})
    random.shuffle(conv_ids); dev_conv = set(conv_ids[: max(1, len(conv_ids) // 20)])
    for fname, default_split in (("aacconversations_en_train.jsonl", "train"), ("aacconversations_en_test.jsonl", "test")):
        for l in open(os.path.join(a.mapped, fname)):
            e = json.loads(l)
            split = "dev" if (default_split == "train" and e["conversation_id"] in dev_conv) else default_split
            ctx = e.get("context_utterances") or []
            hist = [c for c in ctx[:-1]][-2:] if isinstance(ctx, list) else []
            sp, tt = speaker.get(e["id"], ("", ""))
            words = set(re.findall(r"[a-z]+", (tt or "").lower()))
            if words & TOPIC_BIAS and not (set(re.findall(r"[a-z]+", (e.get("partner_utterance") or "").lower())) & TOPIC_BIAS):
                continue   # GPT topic-bias row; drop unless the partner raised the topic
            utts.append((split, "aacconv", setting_of(e.get("scene")), e.get("partner_utterance"), hist, e["acceptable_sequences"], e["id"]))

    # dedupe exact (partner, reference sequence)
    seen = set(); kept = []
    for u in utts:
        key = (u[3], tuple(u[5][0]))
        if key in seen: continue
        seen.add(key); kept.append(u)

    # per-card cap on train reference targets
    ref_count = collections.Counter(c for u in kept if u[0] == "train" for c in u[5][0])
    total = sum(ref_count.values()); cap_n = int(a.cap * total)
    keep_prob = {c: (cap_n / n if n > cap_n else 1.0) for c, n in ref_count.items()}

    writers = {s: open(os.path.join(a.out, f"{s}.jsonl"), "w") for s in ("train", "dev", "test")}
    stats = collections.Counter(); n_states = collections.Counter()
    def tier_of(source, partner, uid):
        if source == "aacconv":
            aac = speaker.get(uid, ("", ""))[0] in ("AAC User", "User")
            return "t1a" if (is_question(partner) and aac) else "t2a"
        if source == "turk": return "t1b" if is_question(partner) else "t2b"
        return "t3"
    TIER_W = {"t1a": 3.0, "t1b": 2.0, "t2a": 1.0, "t2b": 0.8, "t3": 0.6}
    for split, source, setting, partner, hist, seqs, uid in kept:
        if len(seqs[0]) > a.max_cards: stats["too_long"] += 1; continue
        tier = tier_of(source, partner, uid)
        if split == "train":
            # drop the utterance with probability driven by its most over-represented reference card
            p = min(keep_prob.get(c, 1.0) for c in seqs[0]) if seqs[0] else 1.0
            if random.random() > p: stats["capped"] += 1; continue
        for k, (prefix, targets) in enumerate(states_for(seqs)):
            end_only = set(targets) == {"<aac_end>"}
            rec = {"id": f"{uid}_s{k}", "split": split, "source": source, "setting": setting, "tier": tier,
                   "weight": round(TIER_W[tier] * (0.5 if end_only else 1.0), 3),
                   "partner": partner, "history": hist, "prefix": prefix, "targets": targets}
            writers[split].write(json.dumps(rec, ensure_ascii=False) + "\n"); n_states[split] += 1
        stats[f"utts_{split}"] += 1
    for w in writers.values(): w.close()
    print("utterances:", dict(stats)); print("states:", dict(n_states))
    print("train reference-target cap: any card <=", cap_n, "of", total)

if __name__ == "__main__":
    main()
