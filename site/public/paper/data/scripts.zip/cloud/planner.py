#!/usr/bin/env python3
"""Cloud planner / direct-ranker client for the AAC system, using the OpenAI Responses API.

Two modes, one card vocabulary:
  planner : returns context, confidence, category_boosts, intent_paths   (system S6/S7 in PLAN-EXPERIMENTS.md)
  direct  : returns 16 ranked card ids                                    (system S8, the ceiling)

Design points
  * The whole vocabulary (id + spoken form, grouped by category) is the first, stable part of the prompt so
    it is served from the prompt cache; only profile/history/prefix change per call.
  * Strict Structured Outputs: the model can only return the schema fields. Ids are validated against the
    registry afterwards anyway.
  * reasoning.effort defaults to "none" for the planner (latency) and "medium" for direct/judge use.
  * Every call is cached on disk by a hash of (mode, model, effort, inputs) so replays are deterministic
    and free.
  * The key is read from OPENAI_API_KEY or --key-file (default ~/tips/openai.key) and never printed.

Usage
  python3 cloud/planner.py --mode planner --partner "What did you do today at school?" \
      --profile "age 8, school, likes football and drawing, friends Sam and Mia" --setting school
  python3 cloud/planner.py --mode direct  --partner "..." --prefix card_0102 card_0170
"""
import argparse, csv, hashlib, json, os, sys, time, urllib.request, collections

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VOCAB = os.path.join(ROOT, "vocab", "vocab.csv")
REGISTRY = os.path.join(ROOT, "vocab", "registry.json")
CACHE_DIR = os.path.join(ROOT, "cloud", "cache")
DEFAULT_MODEL = "gpt-5.6-luna"

SETTINGS = ["home", "school", "restaurant", "doctor", "play", "transport", "selfcare", "unknown"]

PLANNER_SCHEMA = {
    "type": "object",
    "properties": {
        "context": {"type": "string", "description": "one short phrase describing what the user is probably doing or answering"},
        "confidence": {"type": "number", "description": "0 to 1"},
        "category_boosts": {
            "type": "array",
            "items": {"type": "object",
                      "properties": {"category": {"type": "string"}, "boost": {"type": "number"}},
                      "required": ["category", "boost"], "additionalProperties": False},
            "description": "up to 5 categories that should be favoured, boost 0 to 1"},
        "intent_paths": {
            "type": "array",
            "items": {"type": "object",
                      "properties": {"cards": {"type": "array", "items": {"type": "string"}},
                                     "intent": {"type": "string"}},
                      "required": ["cards", "intent"], "additionalProperties": False},
            "description": "3 to 6 likely complete replies as ordered card ids, most likely first; include at least one refusal or uncertain reply"},
    },
    "required": ["context", "confidence", "category_boosts", "intent_paths"],
    "additionalProperties": False,
}
DIRECT_SCHEMA = {
    "type": "object",
    "properties": {
        "ranked_card_ids": {"type": "array", "items": {"type": "string"},
                            "description": "exactly 16 card ids, best first, no duplicates"},
        "end_probability": {"type": "number", "description": "0 to 1, probability the user is finished with the utterance"},
    },
    "required": ["ranked_card_ids", "end_probability"],
    "additionalProperties": False,
}

def load_vocab():
    rows = list(csv.DictReader(open(VOCAB)))
    reg = json.load(open(REGISTRY))
    return rows, reg["version"]

def vocab_block(rows):
    """Stable, cache-friendly listing: category header then 'id speak' lines. ~3,100 lines."""
    bycat = collections.defaultdict(list)
    for r in rows: bycat[r["category"]].append(r)
    lines = []
    for cat in sorted(bycat):
        lines.append(f"## {cat}")
        lines += [f"{r['id']} {r['speak']}" for r in sorted(bycat[cat], key=lambda r: r["id"])]
    return "\n".join(lines)

def system_prompt(rows, version, mode):
    role = ("You are the context planner inside an AAC (augmentative and alternative communication) app. "
            "The user cannot speak and taps cards to build a reply. Your job is to predict which cards they are "
            "likely to want next, so the app can show them. Use ONLY card ids from the list below. Never invent "
            "ids. The person always chooses what to say; include refusal, uncertainty and repair options so "
            "they are never pushed toward one answer. Prefer short, telegraphic replies (2-5 cards). "
            "<name> stands for a personal name card that the app fills in.")
    if mode == "direct":
        role += (" Return exactly 16 card ids, best first: about 8 most likely next cards for this exact prefix, "
                 "then contrasting options (a refusal or negative, an uncertain reply), then useful core words.")
    else:
        role += (" Return 3-6 intent_paths: each a complete likely reply as ordered card ids starting from the "
                 "current prefix (do not repeat the prefix), most likely first, at least one refusal/negative and "
                 "one uncertain path. Return up to 5 category_boosts from the category headers below.")
    return f"{role}\n\nVocabulary version {version}. Card list (id followed by spoken form), grouped by category:\n{vocab_block(rows)}"

def user_prompt(profile, setting, history, partner, prefix_ids, id2speak):
    parts = []
    if profile: parts.append(f"Profile: {profile}")
    parts.append(f"Setting: {setting or 'unknown'}")
    if history: parts.append("Recent turns:\n" + "\n".join(f"  {h}" for h in history[-4:]))
    parts.append(f"Partner just said: {partner}" if partner else "Nobody has spoken; the user is starting an utterance.")
    if prefix_ids:
        parts.append("Cards already tapped (in order): " + ", ".join(f"{i} ({id2speak.get(i, '?')})" for i in prefix_ids))
    else:
        parts.append("Cards already tapped: none")
    return "\n".join(parts)

def api_key(key_file):
    k = os.environ.get("OPENAI_API_KEY")
    if not k and key_file and os.path.exists(os.path.expanduser(key_file)):
        k = open(os.path.expanduser(key_file)).read().strip()
    if not k: sys.exit("no OpenAI key: set OPENAI_API_KEY or --key-file")
    return k

def call_openai(key, body, timeout=60):
    req = urllib.request.Request("https://api.openai.com/v1/responses", data=json.dumps(body).encode(),
                                 headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"})
    t = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r: out = json.load(r)
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}: {e.read().decode()[:400]}")
    return out, time.time() - t

def parse_output(out):
    for o in out.get("output", []):
        for c in o.get("content", []):
            if c.get("type") == "output_text": return json.loads(c["text"])
    raise RuntimeError("no output_text in response")

def validate(result, mode, valid_ids, prefix_ids):
    """Drop invalid ids; report what was dropped. Never trust model ids blindly."""
    dropped = []
    if mode == "direct":
        seen, keep = set(), []
        for i in result.get("ranked_card_ids", []):
            if i in valid_ids and i not in seen and i not in prefix_ids: keep.append(i); seen.add(i)
            else: dropped.append(i)
        result["ranked_card_ids"] = keep[:16]
    else:
        paths, seen = [], set()
        pre = list(prefix_ids)
        for p in result.get("intent_paths", []):
            cards = [c for c in p.get("cards", []) if c in valid_ids or c == "<name>"]
            dropped += [c for c in p.get("cards", []) if c not in valid_ids and c != "<name>"]
            # the model sometimes repeats the tapped prefix at the start of a path: strip it
            k = 0
            while k < len(cards) and k < len(pre) and cards[k] == pre[k]: k += 1
            cards = cards[k:]
            # and sometimes restates a single tapped card: drop cards already in the prefix
            cards = [c for c in cards if c not in prefix_ids]
            key = tuple(cards)
            if cards and len(cards) <= 6 and key not in seen:
                seen.add(key); paths.append({"cards": cards, "intent": p.get("intent", "")})
        result["intent_paths"] = paths[:6]
        result["confidence"] = min(1.0, max(0.0, float(result.get("confidence", 0))))
    result["_dropped_ids"] = dropped
    return result

def plan(mode, partner, profile="", setting="unknown", history=None, prefix_ids=None, model=DEFAULT_MODEL,
         effort=None, key_file="~/tips/openai.key", use_cache=True, timeout=60):
    rows, version = load_vocab()
    id2speak = {r["id"]: r["speak"] for r in rows}
    valid_ids = set(id2speak)
    prefix_ids = prefix_ids or []; history = history or []
    effort = effort or ("none" if mode == "planner" else "medium")
    sys_p = system_prompt(rows, version, mode)
    usr_p = user_prompt(profile, setting, history, partner, prefix_ids, id2speak)
    body = {"model": model, "reasoning": {"effort": effort},
            "prompt_cache_key": f"aac-{mode}-{version}",
            "input": [{"role": "system", "content": sys_p}, {"role": "user", "content": usr_p}],
            "text": {"format": {"type": "json_schema", "name": mode, "strict": True,
                                "schema": PLANNER_SCHEMA if mode == "planner" else DIRECT_SCHEMA}}}
    h = hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()[:20]
    os.makedirs(CACHE_DIR, exist_ok=True)
    cpath = os.path.join(CACHE_DIR, f"{h}.json")
    if use_cache and os.path.exists(cpath):
        rec = json.load(open(cpath)); rec["from_cache"] = True; return rec
    out, dt = call_openai(api_key(key_file), body, timeout=timeout)
    result = validate(parse_output(out), mode, valid_ids, set(prefix_ids))
    u = out.get("usage", {})
    rec = {"mode": mode, "model": model, "effort": effort, "latency_s": round(dt, 2),
           "usage": {"input": u.get("input_tokens"), "cached": u.get("input_tokens_details", {}).get("cached_tokens"),
                     "output": u.get("output_tokens"), "reasoning": u.get("output_tokens_details", {}).get("reasoning_tokens")},
           "result": result, "from_cache": False, "response_id": out.get("id")}
    json.dump(rec, open(cpath, "w"), indent=1)
    return rec

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["planner", "direct"], default="planner")
    ap.add_argument("--partner", default="")
    ap.add_argument("--profile", default="")
    ap.add_argument("--setting", default="unknown", choices=SETTINGS)
    ap.add_argument("--history", nargs="*", default=[])
    ap.add_argument("--prefix", nargs="*", default=[], help="card ids already tapped")
    ap.add_argument("--model", default=DEFAULT_MODEL)
    ap.add_argument("--effort", default=None, help="none|low|medium|high (default: none for planner, medium for direct)")
    ap.add_argument("--key-file", default="~/tips/openai.key")
    ap.add_argument("--no-cache", action="store_true")
    a = ap.parse_args()
    rec = plan(a.mode, a.partner, a.profile, a.setting, a.history, a.prefix, a.model, a.effort, a.key_file, not a.no_cache)
    rows, _ = load_vocab(); id2speak = {r["id"]: r["speak"] for r in rows}
    print(f"[{rec['mode']}] model={rec['model']} effort={rec['effort']} latency={rec['latency_s']}s cache={'hit' if rec['from_cache'] else 'miss'} usage={rec['usage']}")
    r = rec["result"]
    if a.mode == "planner":
        print(f"context: {r['context']}  confidence: {r['confidence']}")
        print("category_boosts:", {b['category']: b['boost'] for b in r['category_boosts']})
        for p in r["intent_paths"]:
            print(f"  [{p['intent']}] " + " / ".join(f"{c}={id2speak.get(c, c)}" for c in p["cards"]))
    else:
        print(f"end_probability: {r['end_probability']}")
        print("ranked:", ", ".join(f"{c}={id2speak.get(c, c)}" for c in r["ranked_card_ids"]))
    if r.get("_dropped_ids"): print("dropped invalid ids:", r["_dropped_ids"])

if __name__ == "__main__":
    main()
